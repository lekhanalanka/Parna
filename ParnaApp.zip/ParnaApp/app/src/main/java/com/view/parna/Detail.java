package com.view.parna;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Detail extends AppCompatActivity {
ImageView im;
TextView t1,t2,t3,t4;  int i;
String[] s;
JSONArray a,p,des;
String n,n1,n2,n3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        //Log.e("270818","  details");
        t1=findViewById(R.id.t1);
        t2=findViewById(R.id.t2);
        t3=findViewById(R.id.t3);
        t4=findViewById(R.id.t4);
      i=getIntent().getIntExtra("pos",0);
      s=getResources().getStringArray(R.array.plants);
        n=getResources().getString(R.string.cau);
        if(i==0){
            n1=getResources().getString(R.string.plant1);
            n2=getResources().getString(R.string.des1);
            n3="https://www.etsy.com/in-en/listing/594887518/10-seed-betel-nut-palm-fresh-areca?ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=areca%20palm%20seeds&ref=sr_gallery-1-2&organic_search_click=1";
        }
        if(i==1){
            n1=getResources().getString(R.string.plant2);
            n2=getResources().getString(R.string.des2);
            n3="https://www.etsy.com/in-en/listing/631600695/5-seed-lady-palm-japanese-peace-palm?ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=Lady%20palm%20seeds&ref=sr_gallery-1-6&organic_search_click=1";
        }
        t1.setText(n);
        t2.setText(n1);
        t3.setText(n2);
        t4.setText(n3);
        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri= Uri.parse(n3);
                Intent i=new Intent(Intent.ACTION_VIEW,uri);
                startActivity(i);
            }
        });
    }
}
