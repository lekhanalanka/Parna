package com.view.parna;

import android.Manifest;
import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Air extends AppCompatActivity implements LocationListener {
TextView t,t1;
ArrayList<Pojo> lis;
String locality;
String high;
String[] array;
String ss;
LocationManager locationManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_air);
        lis=new ArrayList<Pojo>();
        t=findViewById(R.id.location);
        t1=findViewById(R.id.t1);
        ss="";
        array=getResources().getStringArray(R.array.contents);
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED&& ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},101);

        }
        for(int i=0;i<array.length;i++){
            ss=ss+array[i]+"\n";
        }
        t1.setText(ss.toString());
        getLocation();

    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
        }
        catch (SecurityException se) {
            se.printStackTrace();
        }

        try
        {
            JSONObject data=new JSONObject(String.valueOf(array));
            JSONArray arr=data.getJSONArray("records");
            for(int i=0;i<arr.length();i++) {
                JSONObject ob=arr.getJSONObject(i);
                String id = ob.getString("pollutant_id");
                String max = ob.getString("pollutant_max");
                String min = ob.getString("pollutant_min");
                String avg = ob.getString("pollutant_avg");
            }

        }

        catch (Exception e) {
            e.printStackTrace();
        }
        }

    @Override
    public void onLocationChanged(Location location) {
        //t.setText("Latitude:"+location.getLatitude()+"\nLongitude"+location.getLongitude());
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            t.setText(t.getText()+"\n"+addresses.get(0).getAddressLine(0) + "," + addresses.get(0).getAddressLine(1));
            locality=addresses.get(0).getLocality();
        }
        catch (Exception e) {

        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {
        Toast.makeText(this, "please enable gps", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public void suggest(View view) {
        Intent i=new Intent(this,Suggestions.class);
        i.putExtra("high",high);
        startActivity(i);
    }
}

