package com.view.parna;

public class Pojo {
    String id,min,max,avg;
    public Pojo(String id, String min, String max, String avg) {
        this.id=id;
        this.min=min;
        this.max=max;
        this.avg=avg;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public String getAvg() {
        return avg;
    }

    public void setAvg(String avg) {
        this.avg = avg;
    }
}
