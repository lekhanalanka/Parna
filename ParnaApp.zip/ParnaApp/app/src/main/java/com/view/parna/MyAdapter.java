package com.view.parna;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewholder> {
    Suggestions sug;
    int[] lis;
    public MyAdapter(Suggestions sug, int[] lis) {
        this.sug=sug;
        this.lis=lis;
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(sug).inflate(R.layout.item,null);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewholder holder, final int position) {
        holder.plant.setImageResource(lis[position]);
        holder.plant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  Log.e("270818","  adapter");
                Intent i=new Intent(sug,Detail.class);
                i.putExtra("pos",holder.getAdapterPosition());
                sug.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return lis.length;
    }

    public class MyViewholder extends RecyclerView.ViewHolder {
        ImageView plant;
        public MyViewholder(View itemView) {
            super(itemView);
            plant=itemView.findViewById(R.id.plant);
        }
    }
}
