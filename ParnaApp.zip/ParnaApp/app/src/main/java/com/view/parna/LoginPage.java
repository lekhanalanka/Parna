package com.view.parna;

import android.app.ActivityOptions;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.transition.Explode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginPage extends AppCompatActivity {
    private EditText etUsername;
    private EditText etPassword;
    private Button btGo;
    private CardView cv;
    private FloatingActionButton fab;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        auth=FirebaseAuth.getInstance();
        if(auth.getCurrentUser()!=null){
            startActivity(new Intent(this,HomePage.class));
        }

            initView();
            setListener();

    }

    private void initView() {
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btGo = findViewById(R.id.bt_go);
        cv = findViewById(R.id.cv);
        fab = findViewById(R.id.fab);
    }

    private void setListener() {
        btGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=etUsername.getText().toString().trim();
                String  s1=etPassword.getText().toString().trim();
                if(TextUtils.isEmpty(s) || TextUtils.isEmpty(s1)){
                    if(TextUtils.isEmpty(s)){
                        etUsername.setError("email is empty");
                    }
                    if(TextUtils.isEmpty(s1)){
                        etPassword.setError("password is important");
                    }
                }
                else{
                auth.signInWithEmailAndPassword(s,s1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isSuccessful()){
                            if(etPassword.length()<6){
                                etPassword.setError("length must be less than 6");
                            }
                            Toast.makeText(LoginPage.this, "login fail", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            startActivity(new Intent(LoginPage.this,HomePage.class));
                            finish();
                        }
                    }
                });}

            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getWindow().setExitTransition(null);
                getWindow().setEnterTransition(null);
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(LoginPage.this, fab, fab.getTransitionName());
                startActivity(new Intent(LoginPage.this, RegisPage.class), options.toBundle());
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        fab.setVisibility(View.GONE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        fab.setVisibility(View.VISIBLE);
    }



    public void go(View view) {
        String name=etUsername.getText().toString().trim();
        String pass=etPassword.getText().toString();
    }
}
