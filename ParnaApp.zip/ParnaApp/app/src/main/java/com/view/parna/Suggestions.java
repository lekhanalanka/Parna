package com.view.parna;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class Suggestions extends AppCompatActivity {
    RecyclerView rv;
    String high;
    String[] images;
    int[] img= {R.drawable.ar,R.drawable.ladyp};
    MyAdapter adap;
    String s,name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestions);
        rv = findViewById(R.id.recy);
        high = getIntent().getStringExtra("high");
        rv.setLayoutManager(new LinearLayoutManager(this));
        images = getResources().getStringArray(R.array.plants);
        try {
            JSONObject obj = new JSONObject(images[1]);
            name = obj.getString("name");
            // if(high==name){
            JSONArray link = obj.getJSONArray("image");
            for (int j = 0; j < link.length(); j++) {
                 s = link.getJSONObject(j).getString("image");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        adap = new MyAdapter(this, img);
        rv.setAdapter(adap);
    }
}
